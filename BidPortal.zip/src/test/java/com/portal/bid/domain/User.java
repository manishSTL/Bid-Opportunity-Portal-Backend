package com.portal.bid.domain;

public class User {

}

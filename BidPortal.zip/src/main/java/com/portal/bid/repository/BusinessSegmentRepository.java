package com.portal.bid.repository;

import com.portal.bid.entity.BusinessSegment;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BusinessSegmentRepository extends JpaRepository<BusinessSegment,Long> {
}

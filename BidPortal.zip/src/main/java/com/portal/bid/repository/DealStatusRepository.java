package com.portal.bid.repository;

import com.portal.bid.entity.DealStatus;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DealStatusRepository extends JpaRepository<DealStatus,Long> {
}

package com.portal.bid.repository;

import com.portal.bid.entity.PlanAction;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PlanActionRepository extends JpaRepository<PlanAction,Long> {
}

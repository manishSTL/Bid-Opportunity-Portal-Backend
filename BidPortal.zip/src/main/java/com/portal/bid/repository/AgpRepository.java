package com.portal.bid.repository;


import com.portal.bid.entity.Agp;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AgpRepository extends JpaRepository<Agp,Long> {
}

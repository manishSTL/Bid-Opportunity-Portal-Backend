package com.portal.bid.repository;

import com.portal.bid.entity.GoNoGoStatus;
import org.springframework.data.jpa.repository.JpaRepository;

public interface GoNoGoStatusRepository extends JpaRepository<GoNoGoStatus,Long> {
}

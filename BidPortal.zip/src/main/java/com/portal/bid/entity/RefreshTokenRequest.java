package com.portal.bid.entity;

public class RefreshTokenRequest {
    private String refreshToken;
}
